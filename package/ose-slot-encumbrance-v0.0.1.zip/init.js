import { log } from './module.js';
import

Hooks.on('preUpdateItem', (item, changes, options, ...args) => {

});

Hooks.on('createItem', (item, options, userId, ...args) => {

});

Hooks.on('deleteItem', (item, options, userId, ...args) => {

});

Hooks.on('updateItem', (item, changes, options, userId) => {

});

Hooks.on('renderActorSheet', (actorSheet) => {

});